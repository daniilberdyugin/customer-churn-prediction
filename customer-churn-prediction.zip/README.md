<<<<<<< HEAD
"# Customer Churn Prediction" 
"ML project for predicting customer churn in telecom" 
=======
# customer-churn-prediction
ML project for predicting customer churn in telecom using Kaggle dataset
>>>>>>> f331c3b45c4992b3ba0800b212de09d35350f6c8
